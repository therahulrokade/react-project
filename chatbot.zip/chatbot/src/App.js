import React, { Component } from "react";
import Chatbot from "./components/chatbot/bodycomponent/chatbot";

class App extends Component {
  render() {
    return (
      <div id="chats" className="">
        <div className="chat-window col-xs-12 col-md-12" id="chat_window_1">
          <Chatbot />
        </div>
      </div>
    );
  }
}

export default App;
