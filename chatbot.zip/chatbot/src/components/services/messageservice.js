const axios = require('axios');

export const getMessage = text => {
  var resp = axios.post("/send_text", {
    text
  });

  return resp;
};
