import React, { Component } from "react";
import Message from "../messagecomponent/message";
import * as service from "../../services/messageservice";
import InputComponent from "../inputcomponent/input";

class Chatbot extends Component {
  messagesEnd;
  constructor(props) {
    super(props);
    this._handleInputKeyPress = this._handleInputKeyPress.bind(this);
    this.onClickArrowButton = this.onClickArrowButton.bind(this);
  }

  state = {
    messages: [],
    inputValue: ""
  };

  async text_query(text) {
    let says = {
      speaks: "me",
      msg: {
        card: {
          title: text,
          imageUri: text,
          subtitle: text,
          buttons: [{ text: text, postback: text }]
        },
        text: {
          text: text
        },
        quickReplies: { quickReplies: [text] }
      }
    };

    this.setState({ messages: [...this.state.messages, says] });

    await service
      .getMessage(text)
      .then(resp => {
        for (let msg of resp.data.queryResult.fulfillmentMessages) {
          says = {
            speaks: "bot",
            msg: msg
          };
          this.setState({ messages: [...this.state.messages, says] });
        }
      })
      .catch(error => console.log(error));
  }

  welcome_query(text) {
    service
      .getMessage(text)
      .then(resp => {
        for (let msg of resp.data.queryResult.fulfillmentMessages) {
          let says = {
            speaks: "bot",
            msg: msg
          };
          this.setState({ messages: [...this.state.messages, says] });
        }
      })
      .catch(error => console.log(error));
  }

  componentDidMount() {
    this.welcome_query("hi");
  }

  // scroll down automatically
  componentDidUpdate() {
    this.messagesEnd.scrollIntoView({ behaviour: "smooth" });
  }

  getSelectedButton(e) {
    this.text_query(e);
  }

  navigationButton(e) {
    window.open(e.postback);
  }

  renderMessages(stateMessages) {
    if (stateMessages) {
      return stateMessages.map((message, i) => {
        var parameters = {};
        parameters.key = i;
        parameters.speaks = message.speaks;

        if (message.msg.hasOwnProperty("text")) {
          parameters.text = message.msg.text.text;
        }

        if (
          message.msg.card !== undefined &&
          message.msg.card.title !== undefined
        ) {
          console.log(message.msg.card);
          if (message.msg.card.title !== "Answer") {
            parameters.title = message.msg.card.title;
          }
        }

        if (
          message.msg.card !== undefined &&
          message.msg.card.subtitle !== undefined
        ) {
          parameters.text = message.msg.card.subtitle;
        }

        if (
          message.msg.card !== undefined &&
          message.msg.card.imageUri !== undefined
        ) {
          parameters.imageUri = message.msg.card.imageUri;
        }

        if (
          message.msg.card !== undefined &&
          message.msg.card.buttons !== undefined
        ) {
          parameters.buttons = message.msg.card.buttons[0];
          parameters.selected = this.navigationButton.bind(this);
        }

        if (message.msg.hasOwnProperty("quickReplies")) {
          parameters.quickbuttons = message.msg.quickReplies.quickReplies;
          parameters.selected = this.getSelectedButton.bind(this);
        }

        return (
          <div>
            <Message parameters={parameters} />
          </div>
        );
      });
    } else {
      return null;
    }
  }

  _handleInputKeyPress = e => {
    if (e.target.value !== "") {
      if (e.key === "Enter") {
        this.text_query(e.target.value);
      }
    }
  };

  handleChange(e) {
    this.setState({ inputValue: e.target.value });
  }

  onClickArrowButton = e => {
    if (e !== "") {
      this.text_query(e);
    }
  };

  render() {
    return (
      <div className="toHide">
        <div className="chat-body">
          <div className="chat-body-content">
            {this.renderMessages(this.state.messages)}
            <div
              ref={e => {
                this.messagesEnd = e;
              }}
              style={{ float: "left", clear: "both" }}
            />
          </div>
        </div>
        <div className="chat-footer">
          <InputComponent
            selected={this._handleInputKeyPress.bind(this)}
            arrowButton={this.onClickArrowButton.bind(this)}
          />
        </div>
      </div>
    );
  }
}

export default Chatbot;
