import React from "react";
//import "./message.css";
import Buttons from "./buttons";
import QuickButtons from "./quickButtons";

const Message = props => (
  <div>
    <div className="row msg msg-sent botchat">
      {props.parameters.speaks === "bot" && (
        <div>
          <div className="profile-pic">
            <span className="usericon-cb">
              <img
                className="img-responsive img-rounded"
                src={require("./../../../img/bot-img-sm.png")}
              />
            </span>
          </div>
          <div className="col-xs-12">
            <div className="msg-text">
              <div className="msgtext-content">
                {props.parameters.title !== undefined || null ? (
                  <h4>{props.parameters.title}</h4>
                ) : null}

                {props.parameters.imageUri !== undefined || null ? (
                  <img
                    alt="harbinger_logo"
                    className="img-responsive"
                    src={props.parameters.imageUri}
                  />
                ) : null}

                {props.parameters.text !== undefined || null ? (
                  <p className="mb-2">{props.parameters.text}</p>
                ) : null}
                {props.parameters.buttons !== undefined || null ? (
                  <div>
                    <Buttons
                      buttons={props.parameters.buttons}
                      row={props.parameters.buttons}
                      buttonvalue={props.parameters.selected}
                    />
                  </div>
                ) : null}

                {props.parameters.quickbuttons !== undefined
                  ? props.parameters.quickbuttons.map((element, i) => (
                      <div>
                        <QuickButtons
                          key={i}
                          row={element}
                          quickbuttons={element}
                          buttonvalue={props.parameters.selected}
                        />
                      </div>
                    ))
                  : null}
              </div>
              <div className="el" />
            </div>
          </div>
        </div>
      )}
    </div>
    <div>
      {props.parameters.speaks === "me" && (
        <div className="row msg msg-sent userchat">
          <div className="col-xs-12">
            <div className="msg-text">
              <div className="msgtext-content">{props.parameters.text}</div>
              <div className="el" />
            </div>
          </div>
          <div className="profile-pic">
            <span className="usericon-cb">
              <img
                className="img-responsive img-rounded"
                src={require("./../../../img/user-img-sm.png")}
              />
            </span>
          </div>
        </div>
      )}
    </div>
  </div>
);

export default Message;
