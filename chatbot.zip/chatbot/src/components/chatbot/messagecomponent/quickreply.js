import React, { Component } from "react";

const QuickReplay = props => {
  if (props.replay.card.buttons.postback) {
    return (
      <a
        class="btn-floating btn-large waves-effect waves-light red"
        onClick={event =>
          props.click(event, props.replay.card.buttons.postback)
        }
      >
        {props.replay.card.buttons.postback}
      </a>
    );
  } else {
    return (
      <a
        style={{ margin: 3 }}
        class="btn-floating btn-large waves-effect waves-light red"
        href={props.replay.card.buttons.postback}
      >
        {props.replay.card.buttons.postback}
      </a>
    );
  }
};

export default QuickReplay;
