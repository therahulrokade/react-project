import React, { Component } from "react";
import "./buttons.css";

class QuickButtons extends Component {
  constructor(props) {
    super(props);
  }

  onRowClick() {
    this.props.buttonvalue(this.props.row);
  }

  render() {
    return (
      <div className="btn-option" onClick={this.onRowClick.bind(this)}>
        {this.props.quickbuttons}
      </div>
    );
  }
}

export default QuickButtons;
