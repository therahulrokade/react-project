import React, { Component } from "react";
class InputComponent extends Component {
  constructor(props) {
    super(props);
    this._handleInputKeyPress = this._handleInputKeyPress.bind(this);
    this.onClickArrowButton = this.onClickArrowButton.bind(this);
  }

  state = {
    inputValue: ""
  };

  handleChange(e) {
    this.setState({ inputValue: e.target.value });
  }

  _handleInputKeyPress(e) {
    this.props.selected(e);
    if (e.key === "Enter") {
      this.setState({ inputValue: "" });
    }
  }

  onClickArrowButton = e => {
    this.props.arrowButton(this.state.inputValue);
    this.setState({ inputValue: "" });
  };

  render() {
    return (
      <div className="input-group">
        <input
          id="btn-input"
          type="text"
          name="inputValue"
          value={this.state.inputValue}
          className="form-control input-sm chat_input"
          placeholder="Type your message..."
          onChange={this.handleChange.bind(this)}
          onKeyPress={this._handleInputKeyPress}
        />
        <span className="input-group-btn">
          <button
            type="input"
            name="submit"
            className="btn btn-sm btn-send"
            onClick={this.onClickArrowButton}
            id="btn-chat"
          >
            <img
              src={require("./../../../img/send-icon.png")}
              className="right-img"
            />
          </button>
        </span>
      </div>
    );
  }
}

export default InputComponent;
