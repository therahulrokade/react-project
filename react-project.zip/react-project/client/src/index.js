import React from "react";
import ReactDOM from "react-dom";
import "./index.css";
import App from "./App";
import "../node_modules/bootstrap/dist/css/bootstrap.min.css";
import { BrowserRouter } from "react-router-dom";
import { Provider } from "react-redux";
import { createStore, applyMiddleware, compose, combineReducers } from "redux";
import authReducer from "./store/reducers/auth.jsx";
import operatorReducer from "./store/reducers/operatorReducer.jsx";
import roleReducer from "./store/reducers/roleReducer.jsx";
import thunk from "redux-thunk";

const rootReducer = combineReducers({
  auth: authReducer,
  optr: operatorReducer,
  role: roleReducer
});

const store = createStore(rootReducer, applyMiddleware(thunk));

const app = (
  <Provider store={store}>
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </Provider>
);

ReactDOM.render(app, document.getElementById("root"));
