import React, { Component } from "react";
import "./login";
import "./login.css";
import * as actions from "../../store/actions/auth.jsx";
import { connect } from "react-redux";

class Login extends Component {
  constructor(props) {
    super(props);

    this.state = {
      UserName: "",
      Password: "",
      message: ""
    };
  }
  componentDidMount() {
    if (sessionStorage.getItem("LoggedOut") !== null) {
      this.setState({ message: "You successfully logged out" });
      sessionStorage.removeItem("LoggedOut");
    } else {
      this.setState({ message: "" });
    }
  }

  onChangeUserName(e) {
    this.setState({ UserName: e.target.value });
    this.setState({ message: " " });
  }

  onChangePasswordName(e) {
    this.setState({ Password: e.target.value });
    this.setState({ message: " " });
  }

  submitHandler = e => {
    e.preventDefault();
    this.props.onAuth(this.state.UserName, this.state.Password).then(result => {
      console.log(result);
      if (result.status == 200) {
        this.props.history.push("/navigation");
      } else {
        this.setState({ message: "username and password dosen't match" });
      }
    });
  };

  render() {
    // let authRedirect = null;
    // if (this.props.isAuthenticated) {
    //   console.log(this.props.isAuthenticated);
    //   authRedirect = this.props.history.push("/navigation");
    // }
    return (
      <div className="wrapper fadeInDown">
        {/* {authRedirect} */}
        <div id="formContent">
          <div className="fadeIn first">
            <h2>Login Form</h2>
          </div>
          <input
            type="text"
            className="fadeIn second"
            name="UserName"
            value={this.state.UserName}
            placeholder="Enter User Name"
            onChange={this.onChangeUserName.bind(this)}
          />
          <input
            type="Password"
            className="fadeIn third"
            name="Password"
            value={this.state.Password}
            placeholder="Enter Password"
            onChange={this.onChangePasswordName.bind(this)}
          />
          <input
            type="submit"
            onClick={this.submitHandler}
            className="fadeIn fourth"
            value="Log In"
          />
          <div id="formFooter">
            {this.state.message ? this.state.message : ""}
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    status: state.auth.status || "",
    isAuthenticated: state.auth.token !== null,
    error: state.auth.error
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onAuth: (UserName, Password) => dispatch(actions.auth(UserName, Password))
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Login);
