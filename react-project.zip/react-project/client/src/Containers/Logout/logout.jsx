import React, { Component } from "react";
// import { Redirect } from "react-router-dom";

class Logout extends Component {
  constructor(props) {
    super(props);
    //this.onloginclick = this.onloginclick.bind(this);
  }
  componentDidMount() {
    sessionStorage.removeItem("token");
    sessionStorage.removeItem("roleId");
    sessionStorage.removeItem("UserName");
    sessionStorage.setItem("LoggedOut", "true");
    var h = this.props.history;
    h.push("/login");
  }
  // onloginclick(e) {
  //   var h = this.props.history;
  //   h.push("/login");
  // }
  render() {
    return (
      <div className="Container">
        <h2> You logged out</h2>
        <div>
          <button className="btn btn-warning"> Log In </button>
        </div>
      </div>
    );
  }
}

export default Logout;
