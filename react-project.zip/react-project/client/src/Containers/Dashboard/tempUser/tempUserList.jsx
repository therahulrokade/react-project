import React, { Component } from "react";
import * as actions from "../../../store/actions/operatorActions.jsx";
import { connect } from "react-redux";
import Navigation from "../../../routes/navigation.jsx";
import TempTableRow from "./../../../components/shared/tempTableRow.jsx";
import UserTableHeader from "./../../../components/dashboardComponent/userComponent/userTableHeader";

class TempUserList extends Component {
  constructor(props) {
    super(props);
    this.state = {
      list: this.props.allTempUserList
    };
  }
  componentDidMount() {
    this.props.onFetchTempUser();
  }

  deleteData(row) {
    var user = null;
    user = {
      PersonalUniqueueID: row.UserID,
      FullName: `${row.FirstName}~${row.MiddleName}~${row.LastName}`,
      Gender: row.Gender,
      DateOfBirth: row.DateOfBirth,
      Age: row.Age,
      Address: `${row.FlatOrBungalowNumber}~${row.SocietyName}~${
        row.StreetName
      }`,
      City: row.City,
      State: row.State,
      PinCode: row.PinCode,
      PhoneNo: row.PhoneNo,
      MobileNo: row.MobileNo,
      PhysicalDisability: row.PhysicalDisability,
      MaritalStatus: row.MaritalStatus, //1. Married, Unmarried, Divorced, Widow, Widower, etc
      EducationStatus: row.EducationStatus, // e.g. Masters, Phd, Graduate, Under-Graduate, HSC, SSC, Illiterate, etc.
      BirthSign: row.BirthSign,
      _id: row._id
    };
    this.props.onAcceptUser(user);
    var temparray = [];
    temparray = this.state.list;
    var index = temparray.findIndex(x => x._id == row._id);
    temparray.splice(index, 1);
    this.setState({ lsit: temparray });
  }

  render() {
    return (
      <div>
        <Navigation />
        <div className="container-fluid">
          <table className="table table-bordered table-hover table-secondary">
            <thead>
              <tr>
                <UserTableHeader accessUserList={this.props.allTempUserList} />
              </tr>
            </thead>
            <tbody>
              {this.state.list.map((ele, idx) => (
                <TempTableRow
                  key={idx}
                  userrow={ele}
                  deleterow={this.deleteData.bind(this)}
                />
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    allTempUserList: state.optr.allTempUser || [],
    error: state.optr.error
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onFetchTempUser: () => dispatch(actions.fetchTempUser()),
    onAcceptUser: user => dispatch(actions.AcceptTempUser(user))
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(TempUserList);
