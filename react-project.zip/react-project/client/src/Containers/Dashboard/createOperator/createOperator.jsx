import React, { Component } from "react";
import Navigation from "../../../routes/navigation";
import "./createOperator.css";
import { initOperator } from "../../../store/actions/operatorActions";
import { connect } from "react-redux";
import Options from "../../../components/shared/options.jsx";
import TableHeader from "../../../components/dashboardComponent/operatorComponent/Tableheader";
import OperatorRow from "../../../components/dashboardComponent/operatorComponent/operatorTableRow";

class CreateOperator extends Component {
  state = {
    UserID: this.randomXToY(1001, 1499),
    UserName: "",
    Password: "",
    Email: "",
    RoleId: "",
    allRoleId: ["Operator", "User"]
  };

  randomXToY(minVal, maxVal) {
    var randVal = minVal + Math.random() * (maxVal - minVal);
    return Math.round(randVal);
  }

  onChangeOperator(e) {
    this.setState({ [e.target.name]: e.target.value }, () => {
      console.log(this.state.RoleId);
    });
  }

  onClickClear(e) {
    this.setState({ UserID: "" });
    this.setState({ UserName: "" });
    this.setState({ Password: "" });
    this.setState({ Email: "" });
    this.setState({ RoleId: "" });
    console.log("");
  }

  submitHandler = e => {
    e.preventDefault();
    var user = null;
    user = {
      UserID: this.state.UserID,
      UserName: this.state.UserName,
      Email: this.state.Email,
      Password: this.state.Password,
      RoleId: this.state.RoleId
    };
    this.props.onOperatorAdded(user);
    this.onClickClear();
  };

  render() {
    return (
      <div>
        <Navigation />

        <div className="container">
          <div className="row">
            <div className="modal-content">
              <div>
                <h3 style={{ textAlign: "center" }}>Create New Operator</h3>
              </div>

              <div className="modal-body">
                <div className="row">
                  <div className="modal-body col-mr-6">
                    <div className="form-group">
                      <label>User ID</label>
                      <input
                        type="text"
                        className="form-control"
                        required=""
                        name="UserID"
                        placeholder="Enter User ID"
                        value={this.state.UserID}
                        onChange={this.onChangeOperator.bind(this)}
                        disabled
                      />
                    </div>
                  </div>
                  <div className="modal-body">
                    <div className="form-group col-mr-6">
                      <label>Name</label>
                      <input
                        type="text"
                        className="form-control"
                        required=""
                        name="UserName"
                        placeholder="Enter User Name"
                        value={this.state.UserName}
                        onChange={this.onChangeOperator.bind(this)}
                      />
                    </div>
                  </div>
                </div>
                <div className="row">
                  <div className="modal-body">
                    <div className="form-group">
                      <label>Email </label>
                      <input
                        type="email"
                        className="form-control"
                        required=""
                        name="Email"
                        placeholder="Enter Email address"
                        value={this.state.Email}
                        onChange={this.onChangeOperator.bind(this)}
                      />
                    </div>
                  </div>
                  <div className="modal-body">
                    <div className="form-group">
                      <label>Password</label>
                      <input
                        type="password"
                        className="form-control"
                        required=""
                        name="Password"
                        placeholder="Enter Password"
                        value={this.state.Password}
                        onChange={this.onChangeOperator.bind(this)}
                      />
                    </div>
                  </div>
                </div>
                <div className="row">
                  <div className="modal-body">
                    <div className="form-group">
                      <label>Role Id </label>
                      <select
                        name="RoleId"
                        className="form-control"
                        value={this.state.RoleId}
                        onChange={this.onChangeOperator.bind(this)}
                      >
                        <option defaultValue="-1">Select Role</option>
                        {//console.log(this.props.role)
                        this.props.role.map((c, i) => (
                          <Options key={i} data={c} />
                        ))}
                      </select>

                      {/* <select
                        name="RoleId"
                        className="form-control"
                        value={this.state.RoleId}
                        onChange={this.onChangeOperator.bind(this)}
                      >
                        <option defaultValue="-1">Select Role</option>
                        {this.props.role.map((c, i) =>
                          Object.values(c).map((ele, i) => (
                            <Options key={i} data={ele} />
                          ))
                        )}
                      </select> */}
                    </div>
                  </div>
                </div>
              </div>

              <div className="modal-footer">
                <input type="hidden" name="isEmpty" value="" />
                <button
                  type="input"
                  name="submit"
                  value="newAccount"
                  onClick={this.submitHandler}
                  className="btn btn-success btn-icon pull-right"
                >
                  <i className="fa fa-check" /> Create
                </button>
                <button
                  type="button"
                  className="btn btn-info btn-icon"
                  onClick={this.onClickClear.bind(this)}
                  data-dismiss="modal"
                >
                  <i className="fa fa-times-circle" /> Clear
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    operatorRow: state.optr.operatorRow || "",
    role: state.role.allRole || []
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onOperatorAdded: Operator => dispatch(initOperator(Operator))
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(CreateOperator);
