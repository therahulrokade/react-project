import React, { Component } from "react";
import * as actions from "../../../store/actions/operatorActions.jsx";
import { connect } from "react-redux";
import UserTableRow from "./../../../components/dashboardComponent/userComponent/userTableRow.jsx";
import Navigation from "../../../routes/navigation.jsx";
import UserTableHeader from "./../../../components/dashboardComponent/userComponent/userTableHeader";

class AccessUserList extends Component {
  componentDidMount() {
    this.props.fetchAccessUser();
  }

  getSelectedUserRow(e) {
    this.props.sendAccessUserRowToParent(e);
    this.props.history.push("/user");
  }

  render() {
    return (
      <div>
        <Navigation />
        <div className="container-fluid">
          <table className="table table-bordered table-hover table-secondary">
            <thead>
              <tr>
                <UserTableHeader
                  accessUserList={this.props.allAccessUserList}
                />
              </tr>
            </thead>
            <tbody>
              {this.props.allAccessUserList.map((ele, idx) => (
                <UserTableRow
                  key={idx}
                  userrow={ele}
                  selected={this.getSelectedUserRow.bind(this)}
                />
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    allAccessUserList: state.optr.allAccessUserList || [],
    error: state.optr.error
  };
};

const mapDispatchToProps = dispatch => {
  return {
    fetchAccessUser: () => dispatch(actions.fetchAccessUser()),
    sendAccessUserRowToParent: e =>
      dispatch(actions.sendAccessUserRowToParent(e))
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(AccessUserList);
