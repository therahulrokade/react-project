import React, { Component } from "react";
import Navigation from "./../../../routes/navigation.jsx";
import { connect } from "react-redux";
import * as actions from "./../../../store/actions/roleAction.jsx";

class Roles extends Component {
  constructor(props) {
    super(props);
  }

  state = {
    RoleID: "",
    RoleName: ""
  };

  onClickClear = () => {
    this.setState({ RoleID: "" });
    this.setState({ RoleName: "" });
  };

  onChangeRole(e) {
    this.setState({ [e.target.name]: e.target.value }, () => {});
  }

  submitHandler = e => {
    e.preventDefault();
    var role = null;
    role = {
      RoleID: this.state.RoleID,
      RoleName: this.state.RoleName
    };
    this.props.onOpeartorRoleAdded(role);
    this.onClickClear();
  };

  render() {
    return (
      <div>
        <Navigation />

        <div className="container">
          <div className="row">
            <div className="modal-content">
              <div className="modal-body">
                <div>
                  <h3 style={{ textAlign: "center" }}>Create Role</h3>
                </div>
                <div className="row">
                  <div className="modal-body col-mr-6">
                    <div className="form-group">
                      <label>Role ID</label>
                      <input
                        type="text"
                        className="form-control"
                        required=""
                        name="RoleID"
                        placeholder="Enter Role ID"
                        value={this.state.RoleID}
                        onChange={this.onChangeRole.bind(this)}
                      />
                    </div>
                  </div>
                  <div className="modal-body">
                    <div className="form-group col-mr-6">
                      <label>Name</label>
                      <input
                        type="text"
                        className="form-control"
                        required=""
                        name="RoleName"
                        placeholder="Enter User Name"
                        value={this.state.RoleName}
                        onChange={this.onChangeRole.bind(this)}
                      />
                    </div>
                  </div>
                </div>
              </div>

              <div className="modal-footer">
                <input type="hidden" name="isEmpty" value="" />
                <button
                  type="input"
                  name="submit"
                  value="newAccount"
                  onClick={this.submitHandler}
                  className="btn btn-success btn-icon pull-right"
                >
                  <i className="fa fa-check" /> Create
                </button>
                <button
                  type="button"
                  className="btn btn-info btn-icon"
                  onClick={this.onClickClear.bind(this)}
                  data-dismiss="modal"
                >
                  <i className="fa fa-times-circle" /> Clear
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapDispatchToProps = dispatch => {
  return {
    onOpeartorRoleAdded: role => dispatch(actions.createRole(role))
  };
};

export default connect(
  null,
  mapDispatchToProps
)(Roles);
