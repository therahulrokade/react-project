import React, { Component } from "react";
import * as actions from "../../../store/actions/operatorActions.jsx";
import { connect } from "react-redux";
import OperatorRow from "../../../components/dashboardComponent/operatorComponent/operatorTableRow.jsx";
import Navigation from "../../../routes/navigation.jsx";
import TableHeader from "./../../../components/dashboardComponent/operatorComponent/Tableheader";

class OperatorList extends Component {
  constructor(props) {
    super(props);
  }
  componentDidMount() {
    this.props.onFetchOperator();
    this.getRow();
  }

  getSelectedProduct(e) {
    this.props.sendOperatorRowToParent(e);
    this.props.history.push("/createoperator");
  }

  getRow() {
    console.log(JSON.stringify(this.props.allOperatorsList));
  }

  render() {
    return (
      <div>
        <Navigation />
        <div className="container-fluid">
          <table className="table table-bordered table-hover table-secondary">
            <thead>
              <TableHeader operatorHeaderList={this.props.allOperatorsList} />
            </thead>
            <tbody>
              {this.props.allOperatorsList.map((prd, idx) => (
                <OperatorRow
                  key={idx}
                  row={prd}
                  selected={this.getSelectedProduct.bind(this)}
                />
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    allOperatorsList: state.optr.operators || [],
    error: state.optr.error
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onFetchOperator: () => dispatch(actions.fetchOperators()),
    sendOperatorRowToParent: e => dispatch(actions.sendOperatorRowToParent(e))
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(OperatorList);
