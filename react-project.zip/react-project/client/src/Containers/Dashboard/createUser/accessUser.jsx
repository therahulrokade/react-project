import React, { Component } from "react";
import "./accessUser.css";
import Options from "../../../components/shared/options.jsx";
import Navigation from "../../../routes/navigation";
import { connect } from "react-redux";
import { initAccessUser } from "../../../store/actions/operatorActions";

class AccessUser extends Component {
  state = {
    PersonalUniqueueID: "",
    firstname: "",
    middlename: "",
    lastname: "",
    dob: "",
    age: "",
    flatno: "",
    societyname: "",
    streetname: "",
    city: "",
    state: "",
    pincode: "",
    phoneno: "",
    mobileno: "",
    birthsign: "",
    gender: "",
    IsPhysicalDisability: "",

    MaritatalSelectedStatus: "",
    EducationalSelectedStatus: "",
    MaritatalStatus: ["Married", "Unmarried", "Divorced", "Widow", "Widower"],
    EducationStatus: [
      "Masters",
      "Phd",
      "Graduate",
      " Under-Graduate",
      "HSC",
      "SSC",
      "Illiterate"
    ],
    message: ""
  };

  randomXToY(minVal, maxVal) {
    var randVal = minVal + Math.random() * (maxVal - minVal);
    return Math.round(randVal);
  }

  componentDidMount() {
    this.updateRowDynamically();
  }

  onChangeRegistrationForm(e) {
    this.setState({ [e.target.name]: e.target.value }, () => {});
    this.setState({ message: "" });
  }

  onClickClear = e => {
    this.setState({ PersonalUniqueueID: "" });
    this.setState({ firstname: "" });
    this.setState({ middlename: "" });
    this.setState({ lastname: "" });
    this.setState({ dob: "" });
    this.setState({ age: "" });
    this.setState({ flatno: "" });
    this.setState({ societyname: "" });
    this.setState({ streetname: "" });
    this.setState({ city: "" });
    this.setState({ state: "" });
    this.setState({ pincode: "" });
    this.setState({ phoneno: "" });
    this.setState({ mobileno: "" });
    this.setState({ birthsign: "" });
    this.setState({ gender: "" });
    this.setState({ IsPhysicalDisability: "" });
    this.setState({ MaritatalSelectedStatus: "" });
    this.setState({ EducationalSelectedStatus: "" });
  };

  updateRowDynamically = () => {
    this.setState({
      PersonalUniqueueID: this.props.userRow.UserID
    });
    this.setState({ firstname: this.props.userRow.FirstName });
    this.setState({ middlename: this.props.userRow.MiddleName });
    this.setState({ lastname: this.props.userRow.LastName });
    this.setState({ dob: this.props.userRow.DateOfBirth });
    this.setState({ age: this.props.userRow.Age });
    this.setState({ flatno: this.props.userRow.FlatOrBungalowNumber });
    this.setState({ societyname: this.props.userRow.SocietyName });
    this.setState({ streetname: this.props.userRow.StreetName });
    this.setState({ city: this.props.userRow.City });
    this.setState({ state: this.props.userRow.State });
    this.setState({ pincode: this.props.userRow.PinCode });
    this.setState({ phoneno: this.props.userRow.PhoneNo });
    this.setState({ mobileno: this.props.userRow.MobileNo });
    this.setState({ birthsign: this.props.userRow.BirthSign });
    this.setState({ gender: this.props.userRow.Gender });
    this.setState({
      IsPhysicalDisability: this.props.userRow.PhysicalDisability
    });
    this.setState({
      MaritatalSelectedStatus: this.props.userRow.MaritalStatus
    });
    this.setState({
      EducationalSelectedStatus: this.props.userRow.EducationStatus
    });
  };

  onRegisterHandler = e => {
    e.preventDefault();
    var user = null;
    //console.log(this.state.PersonalUniqueueID);
    var UNiqueId =
      sessionStorage.getItem("roleId") === "1"
        ? this.randomXToY(101, 999)
        : "-1";
    user = {
      PersonalUniqueueID: UNiqueId,
      FullName: `${this.state.firstname}~${this.state.middlename}~${
        this.state.lastname
      }`,
      Gender: this.state.gender,
      DateOfBirth: this.state.dob,
      Age: this.state.age,
      Address: `${this.state.flatno}~${this.state.societyname}~${
        this.state.streetname
      }`,
      City: this.state.city,
      State: this.state.state,
      PinCode: this.state.pincode,
      PhoneNo: this.state.phoneno,
      MobileNo: this.state.mobileno,
      PhysicalDisability: this.state.IsPhysicalDisability,
      MaritalStatus: this.state.MaritatalSelectedStatus, //1. Married, Unmarried, Divorced, Widow, Widower, etc
      EducationStatus: this.state.EducationalSelectedStatus, // e.g. Masters, Phd, Graduate, Under-Graduate, HSC, SSC, Illiterate, etc.
      BirthSign: this.state.birthsign
    };
    //alert(JSON.stringify(user));
    this.props.onAccessUserAdded(user);
    this.onClickClear();
    this.setState({ message: "User created successfully!!!" });
  };

  onclickLogin() {}

  render() {
    return (
      <div>
        <Navigation />

        <div className="container register">
          <div className="row">
            <div className="col-md-3 register-left">
              <h3>Welcome</h3>
              <p>You are now secured in the world of ~Mr.Hellrider!!!</p>
              <br />
            </div>
            <div className="col-md-9 register-right">
              <div className="tab-content" id="myTabContent">
                <div
                  className="tab-pane fade show active"
                  id="home"
                  role="tabpanel"
                  aria-labelledby="home-tab"
                >
                  <div id="formHeader">
                    {this.state.message ? this.state.message : ""}
                  </div>
                  <h3 className="register-heading">Registration Form</h3>
                  <div className="row register-form">
                    <div className="modal-body">
                      <div className="form-group">
                        <div className="col-xs-6">
                          <label>Uniq ID</label>
                          <div className="input-group">
                            <input
                              type="text"
                              className="form-control"
                              name="PersonalUniqueueID"
                              value={this.state.PersonalUniqueueID}
                              placeholder="Uniq ID"
                              required
                              disabled
                            />
                            <span className="input-group-addon">
                              <span className="glyphicon glyphicon-asterisk" />
                            </span>
                          </div>
                          <br />
                          <label>First Name</label>
                          <div className="input-group">
                            <input
                              type="text"
                              className="form-control"
                              name="firstname"
                              value={this.state.firstname}
                              placeholder="Enter First Name"
                              onChange={this.onChangeRegistrationForm.bind(
                                this
                              )}
                              required
                            />
                            <span className="input-group-addon">
                              <span className="glyphicon glyphicon-asterisk" />
                            </span>
                          </div>
                          <br />
                          <label>Middle Name</label>
                          <div className="input-group">
                            <input
                              type="text"
                              className="form-control"
                              value={this.state.middlename}
                              name="middlename"
                              placeholder="Enter Middle Name"
                              onChange={this.onChangeRegistrationForm.bind(
                                this
                              )}
                              required
                            />
                            <span className="input-group-addon">
                              <span className="glyphicon glyphicon-asterisk" />
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="form-group">
                        <div className="col-xs-6">
                          <label>Last Name</label>
                          <div className="input-group">
                            <input
                              type="text"
                              className="form-control"
                              value={this.state.lastname}
                              placeholder="Enter Last Name"
                              name="lastname"
                              onChange={this.onChangeRegistrationForm.bind(
                                this
                              )}
                              required
                            />
                            <span className="input-group-addon">
                              <span className="glyphicon glyphicon-asterisk" />
                            </span>
                          </div>
                          <br />

                          <div className="form-group">
                            <label className="labeltext"> Gender</label>
                            <br />
                            <label className="radio-inline mr-2">
                              <input
                                type="radio"
                                name="gender"
                                value={this.state.gender}
                                onChange={this.onChangeRegistrationForm.bind(
                                  this
                                )}
                              />
                              Male
                            </label>
                            <label className="radio-inline mr-2">
                              <input
                                type="radio"
                                name="gender"
                                value={this.state.gender}
                                onChange={this.onChangeRegistrationForm.bind(
                                  this
                                )}
                              />
                              Female
                            </label>
                            <label className="radio-inline mr-2">
                              <input
                                type="radio"
                                name="gender"
                                value={this.state.gender}
                                onChange={this.onChangeRegistrationForm.bind(
                                  this
                                )}
                              />
                              Other
                            </label>
                          </div>

                          <div className="form-group">
                            <label className="labeltext">
                              {" "}
                              Physical Disability
                            </label>
                            <br />
                            <label className="radio-inline mr-2">
                              <input
                                type="radio"
                                name="IsPhysicalDisability"
                                value={this.state.IsPhysicalDisability}
                                onChange={this.onChangeRegistrationForm.bind(
                                  this
                                )}
                              />
                              Yes
                            </label>
                            <label className="radio-inline mr-2">
                              <input
                                type="radio"
                                name="IsPhysicalDisability"
                                value={this.state.IsPhysicalDisability}
                                onChange={this.onChangeRegistrationForm.bind(
                                  this
                                )}
                              />
                              NO
                            </label>
                          </div>

                          <label>Enter DOB</label>
                          <div className="input-group">
                            <input
                              type="date"
                              className="form-control"
                              value={this.state.dob}
                              name="dob"
                              placeholder="Enter DOB"
                              onChange={this.onChangeRegistrationForm.bind(
                                this
                              )}
                              required
                            />
                            <span className="input-group-addon">
                              <span className="glyphicon glyphicon-asterisk" />
                            </span>
                          </div>
                        </div>
                      </div>

                      <div className="form-group">
                        <div className="col-xs-12">
                          <label>Age</label>
                          <div className="input-group">
                            <input
                              type="number"
                              className="form-control"
                              value={this.state.age}
                              name="age"
                              placeholder="Enter Age"
                              onChange={this.onChangeRegistrationForm.bind(
                                this
                              )}
                              required
                            />
                            <span className="input-group-addon">
                              <span className="glyphicon glyphicon-asterisk" />
                            </span>
                          </div>
                          <br />
                        </div>
                      </div>

                      <div className="form-group">
                        <label>Address</label>
                        <hr />
                        <div className="col-xs-6">
                          <label>Flat/Bungalow Number</label>
                          <div className="input-group">
                            <input
                              type="text"
                              className="form-control"
                              name="flatno"
                              value={this.state.flatno}
                              placeholder="Enter Flat/Bungalow Number"
                              onChange={this.onChangeRegistrationForm.bind(
                                this
                              )}
                              required
                            />
                            <span className="input-group-addon">
                              <span className="glyphicon glyphicon-asterisk" />
                            </span>
                          </div>
                          <br />
                        </div>
                        <div className="col-xs-6">
                          <label>Society Name</label>
                          <div className="input-group">
                            <input
                              type="text"
                              className="form-control"
                              value={this.state.societyname}
                              name="societyname"
                              placeholder="Enter Society Name"
                              onChange={this.onChangeRegistrationForm.bind(
                                this
                              )}
                              required
                            />
                            <span className="input-group-addon">
                              <span className="glyphicon glyphicon-asterisk" />
                            </span>
                          </div>
                          <br />
                        </div>
                        <div className="col-xs-6">
                          <label>Street Name/Area Name</label>
                          <div className="input-group">
                            <input
                              type="text"
                              className="form-control"
                              name="streetname"
                              value={this.state.streetname}
                              placeholder="Enter Street Name/Area Name"
                              onChange={this.onChangeRegistrationForm.bind(
                                this
                              )}
                              required
                            />
                            <span className="input-group-addon">
                              <span className="glyphicon glyphicon-asterisk" />
                            </span>
                          </div>
                          <br />
                        </div>
                      </div>
                      <hr />
                      <div className="form-group">
                        <div className="col-xs-12">
                          <label>City</label>
                          <div className="input-group">
                            <input
                              type="text"
                              className="form-control"
                              value={this.state.city}
                              name="city"
                              placeholder="Enter City"
                              onChange={this.onChangeRegistrationForm.bind(
                                this
                              )}
                              required
                            />
                            <span className="input-group-addon">
                              <span className="glyphicon glyphicon-asterisk" />
                            </span>
                          </div>
                          <br />
                        </div>
                      </div>

                      <div className="form-group">
                        <div className="col-xs-12">
                          <label>State</label>
                          <div className="input-group">
                            <input
                              type="text"
                              name="state"
                              className="form-control"
                              value={this.state.state}
                              placeholder="Enter State"
                              onChange={this.onChangeRegistrationForm.bind(
                                this
                              )}
                              required
                            />
                            <span className="input-group-addon">
                              <span className="glyphicon glyphicon-asterisk" />
                            </span>
                          </div>
                          <br />
                        </div>
                      </div>

                      <div className="form-group">
                        <div className="col-xs-12">
                          <label>Pincode</label>
                          <div className="input-group">
                            <input
                              type="number"
                              name="pincode"
                              className="form-control"
                              value={this.state.pincode}
                              placeholder="Enter Pincode"
                              onChange={this.onChangeRegistrationForm.bind(
                                this
                              )}
                              required
                            />
                            <span className="input-group-addon">
                              <span className="glyphicon glyphicon-asterisk" />
                            </span>
                          </div>
                          <br />
                        </div>
                      </div>

                      <div className="form-group">
                        <div className="col-xs-12">
                          <label>Phone No</label>
                          <div className="input-group">
                            <input
                              type="number"
                              name="phoneno"
                              className="form-control"
                              value={this.state.phoneno}
                              placeholder="Enter Phone No"
                              onChange={this.onChangeRegistrationForm.bind(
                                this
                              )}
                              required
                            />
                            <span className="input-group-addon">
                              <span className="glyphicon glyphicon-asterisk" />
                            </span>
                          </div>
                          <br />
                        </div>
                      </div>

                      <div className="form-group">
                        <div className="col-xs-12">
                          <label>Mobile No</label>
                          <div className="input-group">
                            <input
                              type="number"
                              name="mobileno"
                              className="form-control"
                              value={this.state.mobileno}
                              placeholder="Enter Mobile No"
                              onChange={this.onChangeRegistrationForm.bind(
                                this
                              )}
                              required
                            />
                            <span className="input-group-addon">
                              <span className="glyphicon glyphicon-asterisk" />
                            </span>
                          </div>
                          <br />
                        </div>
                      </div>

                      <div className="form-group">
                        <label>Marital Status </label>
                        <select
                          name="MaritatalSelectedStatus"
                          className="form-control"
                          value={this.state.MaritatalSelectedStatus}
                          onChange={this.onChangeRegistrationForm.bind(this)}
                        >
                          {this.state.MaritatalStatus.map((c, i) => (
                            <Options key={i} data={c} />
                          ))}
                        </select>
                      </div>

                      <div className="form-group">
                        <label>Education Status </label>
                        <select
                          name="EducationalSelectedStatus"
                          className="form-control"
                          value={this.state.EducationalSelectedStatus}
                          onChange={this.onChangeRegistrationForm.bind(this)}
                        >
                          {this.state.EducationStatus.map((c, i) => (
                            <Options key={i} data={c} />
                          ))}
                        </select>
                      </div>

                      <div className="form-group">
                        <div className="col-xs-12">
                          <label>Birth Sign if Any</label>
                          <div className="input-group">
                            <input
                              type="text"
                              className="form-control"
                              name="birthsign"
                              value={this.state.birthsign}
                              placeholder="Enter Birth Sign"
                              onChange={this.onChangeRegistrationForm.bind(
                                this
                              )}
                              required
                            />
                            <span className="input-group-addon">
                              <span className="glyphicon glyphicon-asterisk" />
                            </span>
                          </div>
                          <br />
                        </div>
                      </div>

                      <div className="form-group">
                        <div className="input-group-addon">
                          <input
                            type="button"
                            name="submit"
                            id="submit"
                            value="Clear"
                            onClick={this.onClickClear}
                            className="btn btnClear btn-success pull-left"
                          />
                          {this.props.userRow === "" ? (
                            <input
                              type="button"
                              name="submit"
                              id="submit"
                              value="Register"
                              onClick={this.onRegisterHandler}
                              className="btn btnClear btn-success pull-right"
                            />
                          ) : (
                            <input
                              type="button"
                              name="submit"
                              id="submit"
                              value="Update"
                              onClick={this.onRegisterHandler}
                              className="btn btnClear btn-success pull-right"
                            />
                          )}
                          <div id="formFooter">
                            {this.state.message ? this.state.message : ""}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    userRow: state.optr.userRow || ""
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onAccessUserAdded: user => dispatch(initAccessUser(user))
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(AccessUser);
