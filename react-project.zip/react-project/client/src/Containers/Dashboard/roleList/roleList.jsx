import React, { Component } from "react";
import * as actions from "../../../store/actions/roleAction.jsx";
import { connect } from "react-redux";
import OperatorRow from "../../../components/dashboardComponent/operatorComponent/operatorTableRow.jsx";
import Navigation from "../../../routes/navigation.jsx";
import TableHeader from "./../../../components/dashboardComponent/operatorComponent/Tableheader";

class RoleList extends Component {
  constructor(props) {
    super(props);
  }

  componentDidMount() {
    this.props.onFetchRoles();
  }

  //   getSelectedProduct(e) {
  //     this.props.sendOperatorRowToParent(e);
  //     this.props.history.push("/createoperator");
  //   }

  render() {
    return (
      <div>
        <Navigation />
        <div className="container-fluid">
          <table className="table table-bordered table-hover table-secondary">
            <thead>
              <TableHeader operatorHeaderList={this.props.allOperatorsList} />
            </thead>
            <tbody>
              {this.props.allOperatorsList.map((prd, idx) => (
                <OperatorRow
                  key={idx}
                  row={prd}
                  //selected={this.getSelectedProduct.bind(this)}
                />
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    allOperatorsList: state.role.allRole || [],
    error: state.role.error
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onFetchRoles: () => dispatch(actions.fetchRoles())
  };
};

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(RoleList);
