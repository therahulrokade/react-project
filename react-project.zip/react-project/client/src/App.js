import React, { Component } from "react";
import { Router, Route, Switch } from "react-router-dom";
import Logout from "./Containers/Logout/logout.jsx";
import Navigation from "./routes/navigation.jsx";
import Login from "./Containers/Login/login.jsx";
import history from "./history.js";
import AccessUser from "./Containers/Dashboard/createUser/accessUser.jsx";
import CreateOperator from "./Containers/Dashboard/createOperator/createOperator.jsx";
import OperatorList from "./Containers/Dashboard/operatorList/operatorList.jsx";
import AccessUserList from "./Containers/Dashboard/userList/accessUserList.jsx";
import Roles from "./Containers/Dashboard/roles/createRoles.jsx";
import RoleList from "./Containers/Dashboard/roleList/roleList.jsx";
import TempUserList from "./Containers//Dashboard/tempUser/tempUserList.jsx";

class App extends Component {
  render() {
    return (
      <div>
        <Router history={history}>
          <Switch>
            <Route path="/" component={Login} exact />
            <Route path="/login" component={Login} exact />
            <Route path="/user" component={AccessUser} exact />
            <Route path="/logout" component={Logout} exact />
            <Route path="/navigation" component={Navigation} exact />
            <Route path="/userlist" component={AccessUserList} exact />
            <Route path="/operatorlist" component={OperatorList} exact />
            <Route path="/createroles" component={Roles} exact />
            <Route path="/allroles" component={RoleList} exact />
            <Route path="/alltempuser" component={TempUserList} exact />
            <Route path="/createoperator" component={CreateOperator} exact />
          </Switch>
        </Router>
      </div>
    );
  }
}

export default App;
