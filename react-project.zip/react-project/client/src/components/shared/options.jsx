import React, { Component } from "react";

class Options extends Component {
  render() {
    return (
      <option value={this.props.data.RoleID}>{this.props.data.RoleName}</option>
    );
  }
}

export default Options;

// class Options1 extends Component {
//   render() {
//     return <option value={this.props.data.RoleID}>{this.props.data.RoleName}</option>;
//   }
// }

// export default Options1;
