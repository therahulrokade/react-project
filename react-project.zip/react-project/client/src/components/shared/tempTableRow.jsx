import React, { Component } from "react";
import "./../../App.css";
class TempTableRow extends Component {
  constructor(props) {
    super(props);
    this.state = {
      disableEditBtn: false
    };
  }

  onClickAccept() {
    this.props.deleterow(this.props.userrow);
    this.setState({ disableEditBtn: true });
  }

  render() {
    return (
      <tr>
        {Object.values(this.props.userrow).map((ele, i) =>
          i <= 9 ? (
            <td key={i}>{ele}</td>
          ) : i == 10 ? (
            <td>
              <b>pending</b>
            </td>
          ) : i == 11 ? (
            <td>
              {sessionStorage.getItem("roleId") == 1 ? (
                <input
                  type="submit"
                  className="btn btn-info btn-sm btn-Active"
                  value="Accept"
                  onClick={this.onClickAccept.bind(this)}
                  disabled={this.state.disableEditBtn}
                />
              ) : null}
            </td>
          ) : null
        )}
      </tr>
    );
  }
}

export default TempTableRow;
