import React, { Component } from "react";

class TableHeader extends Component {
  render() {
    return this.props.operatorHeaderList.map((element, idx) =>
      idx == 0
        ? Object.keys(element).map((ele, i) => <th key={i}>{ele}</th>)
        : null
    );
  }
}

export default TableHeader;
