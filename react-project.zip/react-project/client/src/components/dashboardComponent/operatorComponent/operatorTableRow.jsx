import React, { Component } from "react";

class OperatorRow extends Component {
  constructor(props) {
    super(props);
  }

  onRowClick() {
    this.props.selected(this.props.row);
  }

  render() {
    return (
      <tr onClick={this.onRowClick.bind(this)}>
        {Object.values(this.props.row).map((ele, i) => (
          <td key={i}>{ele}</td>
        ))}
      </tr>
    );
  }
}

export default OperatorRow;
