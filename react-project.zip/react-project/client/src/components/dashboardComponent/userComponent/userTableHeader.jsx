import React, { Component } from "react";

class UserTableHeader extends Component {
  render() {
    return this.props.accessUserList.map((element, idx) =>
      idx == 0
        ? Object.keys(element).map((ele, i) =>
            i <= 9 ? <th key={i}>{ele}</th> : i == 10 ? <th>Actions</th> : null
          )
        : null
    );
  }
}

export default UserTableHeader;
