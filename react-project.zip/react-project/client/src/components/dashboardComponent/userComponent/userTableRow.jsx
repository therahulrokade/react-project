import React, { Component } from "react";

class UserTableRow extends Component {
  constructor(props) {
    super(props);
  }

  onRowClick() {
    this.props.selected(this.props.userrow);
  }

  render() {
    return (
      <tr onClick={this.onRowClick.bind(this)}>
        {Object.values(this.props.userrow).map((ele, i) =>
          i <= 9 ? (
            <td key={i}>{ele}</td>
          ) : i == 10 ? (
            <td>
              <button className="btn btn-warning btn-sm" value="Edit">
                Edit
              </button>
            </td>
          ) : null
        )}
      </tr>
    );
  }
}

export default UserTableRow;
