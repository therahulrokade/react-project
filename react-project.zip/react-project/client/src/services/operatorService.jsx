import axios from "axios";

export const CreateOperator = user => {
  var headers = {
    "Content-Type": "application/json",
    Authorization: "bearer " + sessionStorage.getItem("token")
  };
  var resp = axios.post(
    "http://localhost:4090/api/createuser",
    { user },
    { headers: headers }
  );
  return resp;
};

export const getOperator = () => {
  var headers = {
    "Content-Type": "application/json",
    Authorization: "bearer " + sessionStorage.getItem("token")
  };
  var resp = axios.get("http://localhost:4090/api/getalluser", {
    headers: headers
  });
  return resp;
};

export const CreateAccessUser = accessUser => {
  var headers = {
    "Content-Type": "application/json",
    Authorization: "bearer " + sessionStorage.getItem("token"),
    Role: sessionStorage.getItem("roleId")
  };

  var resp = axios.post(
    "http://localhost:4090/api/createnormaluser",
    { accessUser },
    { headers: headers }
  );
  return resp;
};

export const getAllAccessUser = () => {
  var headers = {
    "Content-Type": "application/json",
    Authorization: "bearer " + sessionStorage.getItem("token")
  };
  var resp = axios.get("http://localhost:4090/api/getnormaluserinfo", {
    headers: headers
  });
  return resp;
};

export const getAllTempUser = () => {
  var headers = {
    "Content-Type": "application/json",
    Authorization: "bearer " + sessionStorage.getItem("token")
  };
  var resp = axios.get("http://localhost:4090/api/getalltempuser", {
    headers: headers
  });
  return resp;
};

export const ApproveUser = accessUser => {
  var headers = {
    "Content-Type": "application/json",
    Authorization: "bearer " + sessionStorage.getItem("token"),
    Role: sessionStorage.getItem("roleId")
  };
  var resp = axios.post(
    "http://localhost:4090/api/approveuser",
    { accessUser },
    { headers: headers }
  );
  return resp;
};

// SearchOperator(UserCriteria) {
//   var headers = {
//     "Content-Type": "application/json",
//     Authorization: "bearer " + sessionStorage.getItem("Token"),
//     Role: sessionStorage.getItem("Role"),
//     Criteria: UserCriteria
//   };
//   var resp = axios.get("http://localhost:4090/api/searchoperator", {
//     headers: headers
//   });
//   return resp;
// }
