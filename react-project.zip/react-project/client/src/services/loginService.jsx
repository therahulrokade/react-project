import axios from "axios";

export const AuthUser = (username, password) => {
  var user = {
    UserName: username,
    Password: password
  };
  var resp = axios.post("http://localhost:4090/api/userlogin", { user });
  //console.log(JSON.stringify(resp));
  return resp;
};
