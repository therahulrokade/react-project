import axios from "axios";

export const CreateRole = role => {
  var headers = {
    "Content-Type": "application/json"
  };
  var resp = axios.post(
    "http://localhost:4090/api/createrole",
    { role },
    { headers: headers }
  );
  return resp;
};

export const getRole = () => {
  var headers = {
    "Content-Type": "application/json"
  };
  var resp = axios.get("http://localhost:4090/api/getallroles", {
    headers: headers
  });
  return resp;
};
