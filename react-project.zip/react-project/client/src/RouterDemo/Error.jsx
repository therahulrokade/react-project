import React, { Component } from "react";

class Error extends Component {
  render() {
    return <p>This is from Product</p>;
  }
}

export default Error;
