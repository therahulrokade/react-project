import React, { Component } from "react";
class Home extends Component {
  render() {
    return <div>Hey hii</div>;
  }
}

export default Home;
