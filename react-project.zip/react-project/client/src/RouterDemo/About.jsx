import React, { Component } from "react";

class About extends Component {
  render() {
    return <p>Hey hii</p>;
  }
}

export default About;
