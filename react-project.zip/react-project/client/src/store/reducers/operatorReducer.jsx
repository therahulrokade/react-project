import * as actionTypes from "./../actions/actionTypes.jsx";
import { updatedObject } from "../utility.jsx";

const initialState = {
  operator: null,
  error: false,
  operators: [],
  accessUser: null,
  allAccessUserList: [],
  operatorRow: "",
  userRow: "",
  allTempUser: []
};

const reducer = (state = { initialState }, action) => {
  switch (action.type) {
    case actionTypes.ADD_OPERATOR:
      return updatedObject(state, { operator: action.operator, error: false });

    case actionTypes.ADD_OPERATOR_FAILED:
      return updatedObject(state, { error: true });

    case actionTypes.FETCH_OPERATOR_START:
      return updatedObject(state, { error: false });

    case actionTypes.FETCH_OPERATOR_SUCCESS:
      return updatedObject(state, { operators: action.operators });

    case actionTypes.FETCH_OPERATOR_FAIL:
      return updatedObject(state, { error: true });

    case actionTypes.ADD_ACCESS_USER:
      return updatedObject(state, { accessUser: action.user, error: false });

    case actionTypes.ADD_ACCESS_USER_FAIL:
      return updatedObject(state, { error: true });

    case actionTypes.FETCH_ACCESS_USER_START:
      return updatedObject(state, { error: false });

    case actionTypes.FETCH_ACCESS_USER_SUCCESS:
      return updatedObject(state, {
        allAccessUserList: action.allAccessUser,
        error: false
      });

    case actionTypes.FETCH_ACCESS_USER_FAIL:
      return updatedObject(state, { error: true });

    case actionTypes.SEND_OPERATOR_ROW_SUCCESS:
      return updatedObject(state, { operatorRow: action.operatorRow });

    case actionTypes.SEND_USER_ROW_SUCCESS:
      return updatedObject(state, { userRow: action.userRow });

    case actionTypes.FETCH_TEMP_USER_START:
      return updatedObject(state, { error: false });

    case actionTypes.FETCH_TEMP_USER_SUCCESS:
      return updatedObject(state, {
        allTempUser: action.allTempUser,
        error: false
      });

    case actionTypes.FETCH_TEMP_USER_FAIL:
      return updatedObject(state, { error: true });

    default:
      return state;
  }
};

export default reducer;
