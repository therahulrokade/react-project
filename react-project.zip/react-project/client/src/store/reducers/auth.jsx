import * as actionTypes from "./../actions/actionTypes";
import { updatedObject } from "../utility.jsx";

const initialState = {
  token: null,
  UserName: null,
  status: null,
  roleId: null,
  error: null
};

const authStart = (state, action) => {
  return updatedObject(state, { error: null });
};

const authSuccess = (state, action) => {
  return updatedObject(state, {
    token: action.token,
    UserName: action.UserName,
    status: action.status,
    roleId: action.roleId,
    error: null
  });
};

const authFail = (state, action) => {
  return updatedObject(state, {
    error: action.error
  });
};

const reducer = (state = initialState, action) => {
  switch (action.type) {
    case actionTypes.AUTH_START:
      return authStart(state, action);
    case actionTypes.AUTH_SUCCESS:
      return authSuccess(state, action);
    case actionTypes.AUTH_FAIL:
      return authFail(state, action);
    default:
      return state;
  }
};

export default reducer;
