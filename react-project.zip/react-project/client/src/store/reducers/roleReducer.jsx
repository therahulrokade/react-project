import * as actionTypes from "./../actions/actionTypes.jsx";
import { updatedObject } from "../utility.jsx";

const initialState = {
  role: null,
  allRole: [],
  error: false
};

const reducer = (state = { initialState }, action) => {
  switch (action.type) {
    case actionTypes.CREATE_ROLE:
      return updatedObject(state, { role: action.role });

    case actionTypes.CREATE_ROLE_FAIL:
      return updatedObject(state, { error: true });

    case actionTypes.FETCH_ROLE_FAIL:
      return updatedObject(state, { error: true });

    case actionTypes.FETCH_ROLE_START:
      return updatedObject(state, { error: false });

    case actionTypes.FETCH_ROLE_SUCCESS:
      return updatedObject(state, { allRole: action.allRole });

    default:
      return state;
  }
};

export default reducer;
