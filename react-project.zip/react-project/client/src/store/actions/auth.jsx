import * as actionTypes from "./actionTypes.jsx";
import * as serv from "./../../services/loginService.jsx";

export const authStart = () => {
  return {
    type: actionTypes.AUTH_START
  };
};

export const authSuccess = (token, UserName, roleId, status) => {
  return {
    type: actionTypes.AUTH_SUCCESS,
    token: token,
    UserName: UserName,
    roleId: roleId,
    status: status
  };
};

export const authFail = error => {
  return {
    type: actionTypes.AUTH_FAIL,
    error: error
  };
};

export const auth = (UserName, password) => {
  return dispatch => {
    dispatch(authStart());
    return serv
      .AuthUser(UserName, password)
      .then(result => {
        sessionStorage.setItem("token", result.data.token);
        sessionStorage.setItem("UserName", result.data.UserName);
        sessionStorage.setItem("roleId", result.data.roleId);

        return dispatch(
          authSuccess(
            result.data.token,
            result.data.UserName,
            result.data.roleId,
            result.data.statusCode
          )
        );
      })
      .catch(err => {
        return dispatch(authFail(err));
      });
  };
};
