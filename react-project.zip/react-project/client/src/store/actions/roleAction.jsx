import * as actionTypes from "./actionTypes.jsx";
import * as serv from "./../../services/roleService.jsx";

export const createRoleSuccess = role => {
  return {
    type: actionTypes.CREATE_ROLE,
    role: role
  };
};

export const createRoleFail = error => {
  return {
    type: actionTypes.CREATE_ROLE_FAIL,
    error: error
  };
};

export const createRole = role => {
  return dispatch => {
    serv
      .CreateRole(role)
      .then(result => {
        dispatch(createRoleSuccess(result.data));
      })
      .catch(err => {
        dispatch(createRoleFail(err));
      });
  };
};

export const roleFetchStart = () => {
  return {
    type: actionTypes.FETCH_ROLE_START
  };
};

export const roleFetchSuccess = allRole => {
  return {
    type: actionTypes.FETCH_ROLE_SUCCESS,
    allRole: allRole
  };
};

export const roleFetchFail = error => {
  return {
    type: actionTypes.FETCH_ROLE_FAIL,
    error: error
  };
};

export const fetchRoles = () => {
  return dispatch => {
    roleFetchStart();
    serv
      .getRole()
      .then(res => {
        const fetchRole = [];
        for (let key in res.data.data) {
          fetchRole.push({ ...res.data.data[key] });
        }
        dispatch(roleFetchSuccess(fetchRole));
      })
      .catch(err => {
        dispatch(roleFetchFail(err));
      });
  };
};
