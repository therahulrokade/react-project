import * as actionTypes from "./actionTypes.jsx";
import * as serv from "./../../services/operatorService.jsx";

export const addOperator = operator => {
  return {
    type: actionTypes.ADD_OPERATOR,
    operator: operator
  };
};

export const addOperatorFailed = () => {
  return {
    type: actionTypes.ADD_OPERATOR_FAILED
  };
};

export const initOperator = operator => {
  return dispatch => {
    serv
      .CreateOperator(operator)
      .then(response => {
        console.log(response);
        dispatch(addOperator(response.data));
      })
      .catch(error => {
        dispatch(addOperatorFailed());
      });
  };
};

export const operatorFetchStart = () => {
  return {
    type: actionTypes.FETCH_OPERATOR_START
  };
};

export const operatorFetchSuccess = operators => {
  return {
    type: actionTypes.FETCH_OPERATOR_SUCCESS,
    operators: operators,
    error: false
  };
};

export const operatorFetchFail = error => {
  return {
    type: actionTypes.FETCH_OPERATOR_FAIL,
    error: error
  };
};

export const fetchOperators = () => {
  return dispatch => {
    operatorFetchStart();
    serv
      .getOperator()
      .then(res => {
        const fetchOperators = [];
        for (let key in res.data.data) {
          fetchOperators.push({ ...res.data.data[key] });
        }
        dispatch(operatorFetchSuccess(fetchOperators));
      })
      .catch(err => {
        dispatch(operatorFetchFail(err));
      });
  };
};

export const addAccessUser = user => {
  return {
    type: actionTypes.ADD_ACCESS_USER,
    user: user
  };
};

export const addAccessUserFailed = error => {
  return {
    type: actionTypes.ADD_ACCESS_USER_FAIL,
    error: error
  };
};

export const initAccessUser = user => {
  return dispatch => {
    serv
      .CreateAccessUser(user)
      .then(response => {
        console.log(response);
        dispatch(addAccessUser(response.data));
      })
      .catch(error => {
        dispatch(addAccessUserFailed(error));
      });
  };
};

export const accessUserFetchStart = () => {
  return {
    type: actionTypes.FETCH_ACCESS_USER_START
  };
};

export const accessUserFetchSuccess = allAccessUser => {
  return {
    type: actionTypes.FETCH_ACCESS_USER_SUCCESS,
    allAccessUser: allAccessUser,
    error: false
  };
};

export const accessUserFetchFail = error => {
  return {
    type: actionTypes.FETCH_ACCESS_USER_FAIL,
    error: error
  };
};

export const fetchAccessUser = () => {
  return dispatch => {
    accessUserFetchStart();
    serv
      .getAllAccessUser()
      .then(res => {
        let fetchAccessUser = [];
        for (let key in res.data.data) {
          fetchAccessUser.push({ ...res.data.data[key] });
        }
        dispatch(accessUserFetchSuccess(fetchAccessUser));
      })
      .catch(err => {
        dispatch(accessUserFetchFail(err));
      });
  };
};

export const sendOperatorRow = operatorRow => {
  return {
    type: actionTypes.SEND_OPERATOR_ROW_SUCCESS,
    operatorRow: operatorRow
  };
};

export const sendOperatorRowToParent = operatorRow => {
  return dispatch => {
    dispatch(sendOperatorRow(operatorRow));
  };
};

export const sendUserRow = userRow => {
  return {
    type: actionTypes.SEND_USER_ROW_SUCCESS,
    userRow: userRow
  };
};

export const sendAccessUserRowToParent = userRow => {
  return dispatch => {
    dispatch(sendUserRow(userRow));
  };
};

export const tempUserFetchStart = () => {
  return {
    type: actionTypes.FETCH_TEMP_USER_START
  };
};

export const tempUserFetchSuccess = allTempUser => {
  return {
    type: actionTypes.FETCH_TEMP_USER_SUCCESS,
    allTempUser: allTempUser,
    error: false
  };
};

export const tempUserFetchFail = error => {
  return {
    type: actionTypes.FETCH_TEMP_USER_FAIL,
    error: error
  };
};

export const fetchTempUser = () => {
  return dispatch => {
    tempUserFetchStart();
    serv
      .getAllTempUser()
      .then(res => {
        let fetchTempUser = [];
        for (let key in res.data.data) {
          fetchTempUser.push({ ...res.data.data[key] });
        }
        dispatch(tempUserFetchSuccess(fetchTempUser));
      })
      .catch(err => {
        dispatch(tempUserFetchFail(err));
      });
  };
};

export const AcceptTempUserSuccess = tempUser => {
  return {
    type: actionTypes.ACCEPT_TEMP_USER_SUCCESS,
    tempUser: tempUser
  };
};

export const AcceptTempUserFailed = () => {
  return {
    type: actionTypes.ACCEPT_TEMP_USER_FAILED
  };
};

export const AcceptTempUser = tempUser => {
  return dispatch => {
    serv
      .ApproveUser(tempUser)
      .then(response => {
        dispatch(AcceptTempUserSuccess(response.data));
      })
      .catch(error => {
        dispatch(AcceptTempUserFailed(error));
      });
  };
};
