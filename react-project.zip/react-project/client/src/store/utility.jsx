export const updatedObject = (oldObject, updatedObject) => {
  return {
    ...oldObject,
    ...updatedObject
  };
};
