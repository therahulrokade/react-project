import React, { Component } from "react";
import {
  Nav,
  NavItem,
  Dropdown,
  DropdownItem,
  DropdownToggle,
  DropdownMenu
  //NavLink
} from "reactstrap";

import { NavLink } from "react-router-dom";
import "./navigation.css";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faUser } from "@fortawesome/free-solid-svg-icons";
import { connect } from "react-redux";
import Roles from "./../Containers/Dashboard/roles/createRoles.jsx";
class Navigation extends Component {
  constructor(props) {
    super(props);
  }
  state = {
    UserName: "",
    dropdownOpen: false,
    dropdownOperatorOpen: false,
    dropdownUserOpen: false
  };

  getUserName = () => {
    //var username = sessionStorage.getItem("UserName");
    //username = username.charAt(0).toUpperCase();
    return sessionStorage.getItem("UserName") !== ""
      ? sessionStorage
          .getItem("UserName")
          .charAt(0)
          .toUpperCase() + sessionStorage.getItem("UserName").slice(1)
      : "";
  };
  toggle = () => {
    this.setState({
      dropdownOpen: !this.state.dropdownOpen
    });
  };
  toggleOperator = () => {
    this.setState({
      dropdownOperatorOpen: !this.state.dropdownOperatorOpen
    });
  };
  toggleUser = () => {
    this.setState({
      dropdownUserOpen: !this.state.dropdownUserOpen
    });
  };
  render() {
    return (
      <div>
        <nav
          className="navbar navbar-expand-lg"
          style={{ backgroundColor: "#563d7c" }}
        >
          <a className="navbar-brand nav-link-brand" href="#">
            ~Mr.HellRider ||
          </a>

          <div className="collapse navbar-collapse" id="navbarNavDropdown">
            <ul className="navbar-nav">
              {sessionStorage.getItem("roleId") == 1 ? (
                <Dropdown
                  nav
                  isOpen={this.state.dropdownOpen}
                  toggle={this.toggle}
                >
                  <DropdownToggle nav caret>
                    Roles
                  </DropdownToggle>
                  <DropdownMenu>
                    <DropdownItem className="nav-item">
                      <NavItem>
                        <NavLink className="nav-link" to="/createroles">
                          Create Roles
                        </NavLink>
                      </NavItem>
                    </DropdownItem>
                    <DropdownItem divider />
                    <DropdownItem className="nav-item">
                      <NavItem>
                        <NavLink className="nav-link" to="/allroles">
                          Role List
                        </NavLink>
                      </NavItem>
                    </DropdownItem>
                  </DropdownMenu>
                </Dropdown>
              ) : null}

              {sessionStorage.getItem("roleId") == 1 ? (
                <Dropdown
                  nav
                  isOpen={this.state.dropdownOperatorOpen}
                  toggle={this.toggleOperator}
                >
                  <DropdownToggle nav caret>
                    Operator
                  </DropdownToggle>
                  <DropdownMenu>
                    <DropdownItem className="nav-item">
                      <NavItem>
                        <NavLink className="nav-link" to="/createoperator">
                          Create Operator
                        </NavLink>
                      </NavItem>
                    </DropdownItem>
                    <DropdownItem divider />
                    <DropdownItem className="nav-item">
                      <NavItem>
                        <NavLink className="nav-link" to="/operatorlist">
                          Operator List
                        </NavLink>
                      </NavItem>
                    </DropdownItem>
                  </DropdownMenu>
                </Dropdown>
              ) : null}

              <Dropdown
                nav
                isOpen={this.state.dropdownUserOpen}
                toggle={this.toggleUser}
              >
                <DropdownToggle nav caret>
                  User
                </DropdownToggle>
                <DropdownMenu>
                  <DropdownItem className="nav-item">
                    <NavItem>
                      <NavLink className="nav-link" to="/user">
                        New User
                      </NavLink>
                    </NavItem>
                  </DropdownItem>
                  <DropdownItem divider />
                  <DropdownItem className="nav-item">
                    <NavItem>
                      <NavLink className="nav-link" to="/userlist">
                        User List
                      </NavLink>
                    </NavItem>
                  </DropdownItem>
                </DropdownMenu>
              </Dropdown>

              <li className="nav-item">
                <NavLink className="nav-link" to="/alltempuser">
                  Pending User
                </NavLink>
              </li>
              <li className="nav-item">
                <NavLink className="nav-link" to="/logout" />
              </li>
            </ul>
          </div>
          <div className="floatright">
            <FontAwesomeIcon icon={faUser} className="icon-user" />
            <span className="nav-user">Welcome {this.getUserName()}</span>
            <NavLink to="/logout" className="btn btn-info btn-sm">
              Logout
            </NavLink>
          </div>
        </nav>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return {
    UserName: state.auth.UserName || "",
    roleId: state.auth.roleId || "",
    token: state.auth.token || ""
  };
};

export default connect(
  mapStateToProps,
  null
)(Navigation);
