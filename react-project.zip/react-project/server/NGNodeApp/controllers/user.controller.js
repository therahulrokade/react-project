var mongoose = require('mongoose');
var UserModel = require('./../models/user.model');
var User = mongoose.model("Users");
var express = require('express');
var jwt = require('jsonwebtoken');
var app = express();
var jwtSettings = {
    jwtSecret:"sbibobbompnb37645sbi28yesbi"
};
app.set("jwtSecret",jwtSettings["jwtSecret"]);

var UserController = {};

//Authenticate User
UserController.AuthUser = function(request,response){
    var user = request.body.user;
    User.findOne(user).exec(function(err,res){
        console.log(res);
            if(!err){
                if(res != null){
                   var Token = jwt.sign({user},app.get("jwtSecret"),
                   {
                       expiresIn:3600
                   });
                   response.send({ 
                       statusCode:200,
                       authenticated:true,
                       status:'Profile Created Successful',
                       token:Token
                   });
                }
                else{
                   response.send({ statusCode:404,status:'Some Error Occured..'});
                }
            }
            else{
               response.send({ statusCode:404,status:'Some Error Occured..'});
            }
    });
   
};

//Get User
UserController.GetUserById = function(request,response){
    // var user = {
    //     UserName: request.body.UserName,
    //     PassWord: request.body.PassWord
    // }
    // User.create(user);
};

//Get User
UserController.GetUser = function(request,response){
    // var user = {
    //     UserName: request.body.UserName,
    //     PassWord: request.body.PassWord
    // }
    // User.create(user);
    response.send({Status:`In GetUser.`});
};
//
UserController.GetUserId = function(request,response){
    var UserId = User.find({}).sort({_id:-1}).limit(1);
    console.log(JSON.stringify(UserId));
    //response.send({UserID : UserId});
};
//Create User
UserController.Create = function(request,response){
     var user = request.body.user;
    //{
    //     UserName: request.body.UserName,
    //     PassWord: request.body.PassWord
    //     UserID : request.body.UserID,
    //     Email:request.body.Email,
    //     RoleId : request.body.RoleId 
    //}
    // user.UserID = User.find({}).sort({_id:-1}).limit(1);
    // console.log(user.UserID);
     User.create(user,function(err,res){
         if(!err){
            if(res != null){
                response.send({data : res});
            }
            else{
                response.send({error: 'User Creation Failed.'});
            }
         }
         else{
            response.send({error: err});
        }
     });
};

//Update User
UserController.Update = function(request,response){
    // var user = {
    //     UserName: request.body.UserName,
    //     PassWord: request.body.PassWord
    // }
    // User.create(user);
    console.log("this is Update");
};

//Delete User
UserController.Delete = function(request,response){
    // var user = {
    //     UserName: request.body.UserName,
    //     PassWord: request.body.PassWord
    // }
    // User.create(user);
    console.log("this is Delete");
};

module.exports = UserController;
