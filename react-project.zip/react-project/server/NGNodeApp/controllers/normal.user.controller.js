var mongoose = require('mongoose');
var AccessUserModel = require('./../models/normal.user.model');
var AccessUser = mongoose.model("AccessUser");

var AccessUserController = {};

//Authenticate Access User
AccessUserController.AuthAccessUser = function(request,response){
      
};

//Get Normal User
AccessUserController.GetById = function(request,response){
    // var user = {
    //     UserName: request.body.UserName,
    //     PassWord: request.body.PassWord
    // }
    // AccessUser.create(user);
};

//Create Normal User
AccessUserController.Create = function(request,response){
    var user = {
        UserName: request.body.UserName,
        PassWord: request.body.PassWord
    }
    AccessUser.create(user);
};

//Update Normal User
AccessUserController.Update = function(request,response){
    // var user = {
    //     UserName: request.body.UserName,
    //     PassWord: request.body.PassWord
    // }
    // AccessUser.create(user);
};

//Delete Normal User
AccessUserController.Delete = function(request,response){
    // var user = {
    //     UserName: request.body.UserName,
    //     PassWord: request.body.PassWord
    // }
    // AccessUser.create(user);
};

module.exports = AccessUserController;
