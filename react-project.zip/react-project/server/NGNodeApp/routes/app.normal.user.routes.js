var express = require('express');
var router = express.Router();

var NormalUserController = require('../controllers/normal.user.controller');

//Auth Normal User
//router.get('/api/accessuserlogin',function(req,res){NormalUserController.AuthAccessUser(req,res)});

//Normal User CRUD Operations

router.get('/api/getnormaluserinfo/:id',function(req,res){NormalUserController.GetById(req,res)});

router.post('/api/createnormaluser',function(req,res){ NormalUserController.Create(req,res)});

router.put('/api/updatenormaluser/:id',function(req,res){ NormalUserController.Update(req,res)});

router.delete('/api/deletenormaluser/:id',function(req,res){ NormalUserController.Delete(req,res)});

module.exports = router;