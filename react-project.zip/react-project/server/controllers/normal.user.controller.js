var mongoose = require("mongoose");
var AccessUserModel = require("./../models/normal.user.model");
var AccessUser = mongoose.model("AccessUser");
var TempAccessUser = mongoose.model("TempAccessUser");
var express = require("express");
var jwt = require("jsonwebtoken");
var app = express();
var jwtSettings = {
  jwtSecret: "sbibobbompnb37645sbi28yesbi"
};
app.set("jwtSecret", jwtSettings["jwtSecret"]);

var AccessUserController = {};

//Authenticate Access User
AccessUserController.AuthAccessUser = function(request, response) {};

//Get Normal User
AccessUserController.GetAllNormalUserInfo = function(request, response) {
  var tokenRecived = request.headers.authorization.split(" ")[1];
  jwt.verify(tokenRecived, app.get("jwtSecret"), function(err, decoded) {
    if (err) {
      response.send({ success: false, message: "Token verification failed" });
    } else {
      request.decoded = decoded;
      var query = AccessUser.find({}).select("-_id -__v -updatedAt");
      query.exec(function(err, res) {
        if (!err) {
          if (res != null) {
            var returnedObjects = [];
            res.forEach(element => {
              //console.log(element);
              //console.log(element.FullName.split("~"));
              var Obj = new Object();
              var Obj1 = new Object();
              Obj.UserID = element.PersonalUniqueueID;
              Obj1.FullName = element.FullName;
              Obj.FirstName = Obj1.FullName.split("~")[0];
              Obj.MiddleName = Obj1.FullName.split("~")[1];
              Obj.LastName = Obj1.FullName.split("~")[2];
              Obj.DateOfBirth = element.DateOfBirth;
              Obj.Age = element.Age;
              Obj.City = element.City;
              Obj.MobileNo = element.MobileNo;
              var date = new Date(element.createdAt);
              date = date.toUTCString();
              Obj.createdAt = date;
              Obj.BirthSign = element.BirthSign;
              Obj.Gender = element.Gender;
              Obj1.Address = element.Address;
              Obj.FlatOrBungalowNumber = Obj1.Address.split("~")[0];
              Obj.SocietyName = Obj1.Address.split("~")[1];
              Obj.StreetName = Obj1.Address.split("~")[2];
              Obj.State = element.State;
              Obj.PinCode = element.PinCode;
              Obj.PhoneNo = element.PhoneNo;
              Obj.PhysicalDisability = element.PhysicalDisability;
              Obj.MaritalStatus = element.MaritalStatus;
              Obj.EducationStatus = element.EducationStatus;
              returnedObjects.push(Obj);
            });
            //console.log(returnedObjects);
            response.send({ data: returnedObjects });
          } else {
            response.send({ error: "User Creation Failed." });
          }
        } else {
          response.send({ error: err });
        }
      });
    }
  });
};

//Create Normal User
AccessUserController.Create = function(request, response) {
  var accessUser = request.body.accessUser;
  var tokenRecived = request.headers.authorization.split(" ")[1];
  var Role = request.headers.role;
  jwt.verify(tokenRecived, app.get("jwtSecret"), function(err, decoded) {
    if (err) {
      response.send({ success: false, message: "Token verification failed" });
    } else {
      request.decoded = decoded;
      if (Role === "1") {
        AccessUser.create(accessUser, function(err, res) {
          if (!err) {
            if (res != null) {
              response.send({
                data: res,
                statusMessage: "User Created Successful",
                statusCode: 200
              });
            } else {
              response.send({ error: "User Creation Failed." });
            }
          } else {
            response.send({ error: err });
          }
        });
      } else {
        TempAccessUser.create(accessUser, function(err, res) {
          if (!err) {
            if (res != null) {
              response.send({
                data: res,
                statusMessage: "User Created Successful",
                statusCode: 200
              });
            } else {
              response.send({ error: "User Creation Failed." });
            }
          } else {
            response.send({ error: err });
          }
        });
      }
    }
  });
};

//Update Normal User
AccessUserController.Update = function(request, response) {
  // var user = {
  //     UserName: request.body.UserName,
  //     PassWord: request.body.PassWord
  // }
  // AccessUser.create(user);
};

//Delete Normal User
AccessUserController.Delete = function(request, response) {
  // var user = {
  //     UserName: request.body.UserName,
  //     PassWord: request.body.PassWord
  // }
  // AccessUser.create(user);
};

AccessUserController.GetAllTempUser = function(request, response) {
  var tokenRecived = request.headers.authorization.split(" ")[1];
  jwt.verify(tokenRecived, app.get("jwtSecret"), function(err, decoded) {
    if (err) {
      response.send({ success: false, message: "Token verification failed" });
    } else {
      request.decoded = decoded;
      var query = TempAccessUser.find({}).select("-__v -updatedAt");
      query.exec(function(err, res) {
        if (!err) {
          if (res != null) {
            var returnedObjects = [];
            res.forEach(element => {
              var Obj = new Object();
              var Obj1 = new Object();
              Obj.UserID = element.PersonalUniqueueID;
              Obj1.FullName = element.FullName;
              Obj.FirstName = Obj1.FullName.split("~")[0];
              Obj.MiddleName = Obj1.FullName.split("~")[1];
              Obj.LastName = Obj1.FullName.split("~")[2];
              Obj.DateOfBirth = element.DateOfBirth;
              Obj.Age = element.Age;
              Obj.City = element.City;
              Obj.MobileNo = element.MobileNo;
              Obj1.Address = element.Address;
              var date = new Date(element.createdAt);
              date = date.toUTCString();
              Obj.createdAt = date;
              returnedObjects.push(Obj);
              Obj.BirthSign = element.BirthSign;
              Obj.Gender = element.Gender;
              Obj.FlatOrBungalowNumber = Obj1.Address.split("~")[0];
              Obj.SocietyName = Obj1.Address.split("~")[1];
              Obj.StreetName = Obj1.Address.split("~")[2];
              Obj.State = element.State;
              Obj.PinCode = element.PinCode;
              Obj._id = element._id;
              Obj.PhoneNo = element.PhoneNo;
              Obj.PhysicalDisability = element.PhysicalDisability;
              Obj.MaritalStatus = element.MaritalStatus;
              Obj.EducationStatus = element.EducationStatus;
            });
            //console.log(returnedObjects);
            response.send({ data: returnedObjects });
          } else {
            response.send({ error: "User Creation Failed." });
          }
        } else {
          response.send({ error: err });
        }
      });
    }
  });
};

AccessUserController.Approve = function(request, response) {
  //JSON.stringify(obj1) === JSON.stringify(obj2)
  var accessUser = request.body.accessUser;
  var id = accessUser._id;
  var tokenRecived = request.headers.authorization.split(" ")[1];
  var Role = request.headers.role;
  jwt.verify(tokenRecived, app.get("jwtSecret"), function(err, decoded) {
    if (err) {
      response.send({ success: false, message: "Token verification failed" });
    } else {
      request.decoded = decoded;
      if (Role === "1") {
        TempAccessUser.deleteOne({ _id: id }, function(err, res) {
          if (!err) {
            if (res != null) {
              if (res.deletedCount > 0) {
                let newPersonalUniqueueID = "";
                delete accessUser._id;
                AccessUser.find()
                  .sort({ PersonalUniqueueID: -1 })
                  .limit(1)
                  .exec(function(err, res) {
                    let maxpersonalId = res[0].PersonalUniqueueID;
                    newPersonalUniqueueID = parseInt(maxpersonalId) + 1;
                    accessUser.PersonalUniqueueID = newPersonalUniqueueID;

                    console.log(accessUser);
                    if (err) {
                      response.send({
                        statusMessage: "User Creation Failed.",
                        statusCode: 402
                      });
                    } else {
                      AccessUser.create(accessUser, function(err, res) {
                        if (!err) {
                          if (res != null) {
                            response.send({
                              data: res,
                              statusMessage: "User Created Successful",
                              statusCode: 200
                            });
                          } else {
                            response.send({ error: "User Creation Failed." });
                          }
                        } else {
                          response.send({ error: err });
                        }
                      });
                    }
                  });
              }
            }
          }
        });
      }
    }
  });
};

// UserController.SearchOperator = function(request, response) {
//   var tokenRecived = request.headers.authorization.split(" ")[1];
//   var Criteria = request.headers.criteria;
//   //console.log(Criteria);
//   jwt.verify(tokenRecived, app.get("jwtSecret"), function(err, decoded) {
//     if (err) {
//       response.send({ success: false, message: "Token verification failed" });
//     } else {
//       request.decoded = decoded;
//       var query = User.find({ UserName: Criteria }).select(
//         "-_id -__v -updatedAt"
//       );
//       //console.log(query);
//       query.exec(function(err, res) {
//         if (!err) {
//           if (res != null) {
//             console.log(res);
//             var returnedObjects = [];
//             res.forEach(element => {
//               var Obj = new Object();
//               Obj.UserID = element.UserID;
//               Obj.UserName = element.UserName;
//               Obj.Email = element.Email;
//               Obj.Password = element.Password;
//               Obj.RoleId = element.RoleId;
//               var date = new Date(element.createdAt);
//               date = date.toUTCString();
//               Obj.createdAt = date;
//               returnedObjects.push(Obj);
//             });
//             response.send({ data: returnedObjects });
//           } else {
//             response.send({ error: "User Search Failed." });
//           }
//         } else {
//           response.send({ error: err });
//         }
//       });
//     }
//   });
// };

module.exports = AccessUserController;
